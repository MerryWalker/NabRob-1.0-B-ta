1.0.0 / 2016-08-22
==================

  * Initial stable release
