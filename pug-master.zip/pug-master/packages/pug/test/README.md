# Running Tests

To run tests (with node.js installed) you must complete 2 steps.

## 1 Install dependencies

```
npm install
```

## 2 Run tests

```
npm test
```
